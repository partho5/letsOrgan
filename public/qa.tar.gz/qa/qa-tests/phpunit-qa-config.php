<?php
// Stand-in config file for PHPUnit

define('QA_MYSQL_HOSTNAME', '');
define('QA_MYSQL_USERNAME', '');
define('QA_MYSQL_PASSWORD', '');
define('QA_MYSQL_DATABASE', '');

define('QA_MYSQL_TABLE_PREFIX', 'qa_');
define('QA_EXTERNAL_USERS', false);
