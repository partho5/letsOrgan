<?php
/**
 * @deprecated This file is deprecated from Q2A 1.7; use the below file instead.
 */

require_once QA_INCLUDE_DIR.'pages/admin/admin-points.php';
